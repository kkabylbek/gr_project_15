//
//  Timer.swift
//  GR_Project
//
//  Created by Хамза Кабылбек on 05.11.2023.
//
//

import UIKit

class TimerViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    var timer: Timer?
    var secondsRemaining: Int = 0
    var isTimerRunning: Bool = false

    // MARK: -  TIME Label
    let timeLabel: UILabel = {
        let label = UILabel()
        label.text = "00:00"
        label.textColor  = .black
        //label.font = UIFont.systemFont(ofSize: 60)
        label.font = .boldSystemFont(ofSize: 65)
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    // MARK: - UIPicker Time picker
    let timePicker: UIPickerView = {
        let picker = UIPickerView()
        //picker.backgroundColor = .yellow  // Устанавливаем желтый цвет фона
        picker.backgroundColor = .systemTeal
        picker.translatesAutoresizingMaskIntoConstraints = false

        return picker
    }()
    
    // MARK: - startStopButton
    let startStopButton: UIButton = {
        let button = UIButton()
        button.setTitle("Start", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = .systemBlue
        button.layer.cornerRadius = 10
        button.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    // MARK: - resetButton
    let resetButton: UIButton = {
        let button = UIButton()
        button.setTitle("Reset", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = .systemRed
        button.layer.cornerRadius = 10
        button.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        //navigationItem.title = "Timer"
        


        view.addSubview(timeLabel)
        view.addSubview(timePicker)
        view.addSubview(startStopButton)
        view.addSubview(resetButton)
        
        //timePicker.backgroundColor = .yellow  // Устанавливаем желтый цвет фона
        timePicker.backgroundColor = .systemCyan// Изменение цвета на системный синий (systemBlue)
        view.backgroundColor = .systemCyan




        timeLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        timeLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: 100).isActive = true

        timePicker.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        timePicker.topAnchor.constraint(equalTo: timeLabel.bottomAnchor, constant: 20).isActive = true

        startStopButton.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: -70).isActive = true
        startStopButton.topAnchor.constraint(equalTo: timePicker.bottomAnchor, constant: 20).isActive = true
        startStopButton.widthAnchor.constraint(equalToConstant: 120).isActive = true
        startStopButton.heightAnchor.constraint(equalToConstant: 40).isActive = true

        resetButton.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: 70).isActive = true
        resetButton.topAnchor.constraint(equalTo: timePicker.bottomAnchor, constant: 20).isActive = true
        resetButton.widthAnchor.constraint(equalToConstant: 120).isActive = true
        resetButton.heightAnchor.constraint(equalToConstant: 40).isActive = true

        startStopButton.addTarget(self, action: #selector(startStopButtonTapped), for: .touchUpInside)
        resetButton.addTarget(self, action: #selector(resetButtonTapped), for: .touchUpInside)

        timePicker.delegate = self
        timePicker.dataSource = self
        timePicker.selectRow(1, inComponent: 0, animated: false)
    }


    
    @objc func startStopButtonTapped() {
        if isTimerRunning {
            pauseTimer()
        } else {
            startTimer()
        }
    }
    
    @objc func resetButtonTapped() {
        stopTimer()
        secondsRemaining = 0
        updateTimerLabel()
    }
    
    func startTimer() {
        secondsRemaining = ((timePicker.selectedRow(inComponent: 0) + 1) * 5) * 60
        updateTimerLabel()
        
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateTime), userInfo: nil, repeats: true)
        isTimerRunning = true
        startStopButton.setTitle("Pause", for: .normal)
    }
    
    func pauseTimer() {
        timer?.invalidate()
        isTimerRunning = false
        startStopButton.setTitle("Start", for: .normal)
    }
    
    func stopTimer() {
        timer?.invalidate()
        isTimerRunning = false
        updateTimerLabel()
        startStopButton.setTitle("Start", for: .normal)
    }
    
    @objc func updateTime() {
        if secondsRemaining > 0 {
            secondsRemaining -= 1
            updateTimerLabel()
        } else {
            stopTimer()
            // Здесь можно добавить звуковой сигнал или уведомление о завершении
        }
    }
    
    func updateTimerLabel() {
        let minutes = secondsRemaining / 60
        let seconds = secondsRemaining % 60
        timeLabel.text = String(format: "%02d:%02d", minutes, seconds)
    }

    
    // MARK: - UIPickerViewDataSource
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return 12 // 5 to 60 minutes with 5-minute intervals (excluding 0)
    }
    
    // MARK: - UIPickerViewDelegate
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        let minutes = (row + 1) * 5
        return "\(minutes) min"
    }
}

