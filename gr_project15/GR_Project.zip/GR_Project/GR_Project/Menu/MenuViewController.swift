//
//  MenuViewController.swift
//  GR_Project
//
//  Created by Хамза Кабылбек on 05.11.2023.
//

import UIKit
import Foundation

struct Note {
    let title: String
    let content: String
    var isCompleted: Bool

    init(title: String, content: String, isCompleted: Bool = false) {
        self.title = title
        self.content = content
        self.isCompleted = isCompleted
    }
}

class MenuViewController: UIViewController {

    var notes = [Note]()

    lazy var tableView: UITableView = {
        let tableView = UITableView(frame: view.bounds, style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        return tableView
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemGray

        //nav
        let appearance = UINavigationBarAppearance()
        appearance.backgroundColor = .systemBlue
        appearance.largeTitleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        //self.navigationItem.standardAppearance = appearance
        self.navigationItem.scrollEdgeAppearance = appearance
        navigationItem.title = "Note📋"
        navigationController?.navigationBar.prefersLargeTitles = true

        let addButton = UIBarButtonItem(title: "Add notes📝", style: .plain, target: self, action: #selector(addNote))
        navigationItem.rightBarButtonItem = addButton
        addButton.tintColor = .white
        view.addSubview(tableView)

        tableView.register(NoteTableViewCell.self, forCellReuseIdentifier: "NoteCell")
        
    }
    
    @objc func addNote() {
        let addNoteViewController = AddNoteViewController()
        addNoteViewController.delegate = self
        let navigationController = UINavigationController(rootViewController: addNoteViewController)
        present(navigationController, animated: true, completion: nil)
    }
    
}

extension MenuViewController: AddNoteDelegate {
    func didAddNote(note: Note) {
        notes.append(note)
        tableView.reloadData()
    }
    
    func didCompleteNoteAtIndex(_ index: Int) {
        notes[index].isCompleted = !notes[index].isCompleted
        tableView.reloadRows(at: [IndexPath(row: index, section: 0)], with: .none)
    }
}

extension MenuViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return notes.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NoteCell", for: indexPath) as! NoteTableViewCell
        let note = notes[indexPath.row]
        cell.configure(with: note, index: indexPath.row)
        cell.delegate = self
        
//        cell.contentView.layer.cornerRadius = 10
//        cell.contentView.clipsToBounds = true
        
        return cell as UITableViewCell // Явное приведение к типу UITableViewCell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        // Верните желаемую высоту для каждой ячейки, которая влияет на интервал
        return 80.0 // Измените это значение для управления высотой ячейки и интервалом
    }
    
    // Добавление свайпа для удаления элемента из списка заметок
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            notes.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }

    // Установка стиля удаления
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return .delete
    }
    

    

}


extension MenuViewController: NoteCellDelegate {
    func didToggleCheckbox(atIndex index: Int) {
        notes[index].isCompleted.toggle()
        tableView.reloadData()
    }
}

